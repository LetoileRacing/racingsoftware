L'ETOILE RACE ANALYST - WINDOWS 7 (64-BIT) - VERSION 0.2

NO PYTHON REQUIRED.

1. Unzip the package to a folder on your Windows 7 computer.
2. Double-click LEtoile_Race_Analyst.hta.
3. Use Play to watch the sample race. Pause and Restart work too.
4. Export demo CSV to see the data format.
5. To view your own race data, select a CSV with columns:
   twd,tws,hdg,stw,sog,vmg
   Wind direction and heading in degrees; speeds in knots.

This is a Windows HTML Application (.hta), not a compiled .exe.
It uses the built-in Windows mshta.exe host and Internet Explorer 9 canvas.
Internet Explorer 9 or later must be installed for the charts to work.
HTA is an old Windows technology with broad local file permissions:
only open HTA programs you trust; do not run untrusted HTA files.

This version DOES NOT connect to the Actisense NGT-1, Raymarine Wi-Fi,
SeaTalkNG, or AIS. It is an offline demonstration and CSV replay viewer.
Do not use for navigation or safety-critical decisions.

Tested for packaging and source inspection only; Windows 7 runtime
has not been tested in this environment.
